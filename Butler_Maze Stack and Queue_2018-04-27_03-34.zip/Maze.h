#ifndef MAZEH
#define MAZEH
#include <string>
#include <array>
#include <stack>
#include <queue>
#include "Space.h"

class Maze{
        public:
                Maze(); //constructors
                Maze(std::string maze, int initialR, int initialC); //expected ) before maze if you do not include the std:: part
                bool setInitial(int r, int c);
                Space getSpace(int r, int c);
                std::stack<Space> getFreeNeighborsStack(Space currentSpace);
                bool findExitStack(Space currentSpace);
                std::stack<Space> getSolutionStack();
                std::queue<Space> getFreeNeighborsQueue(Space currentSpace);
                bool findExitQueue(Space currentSpace);
                void printMaze();

        private:
                Space grid[100][100]; //was Space[][] grid;
//is using 100x100 detrimental?
                int rows, cols;
                int currentR, currentC;
                std::stack<Space> freeNeighborsStack;   //will use two stacks  
                std::stack<Space> solutionStack;
                std::queue<Space> freeNeighborsQueue;   //will use two queues
                std::queue<Space> solutionQueue;
};
#endif


