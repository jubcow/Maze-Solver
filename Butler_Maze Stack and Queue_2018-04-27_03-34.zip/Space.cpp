#ifndef SPACECPP
#define SPACECPP
#include <vector>
#include <string>
#include "Space.h"
using namespace std;

//set Entry <--- Needed?

Space::Space(){
    row = 0;
    col = 0;
    type.reserve(4);
    type[0] = '*'; //default type so the maze is surrounded by these, cannot see when maze is printed correctly.
    type[1] = 'f'; //path, but going to just include it in [0]
    type[2] = 'f'; //visited
    type[3] = 'f'; //exit
}
Space::Space(char typ, int rowi, int coli){

    row = rowi;
    col = coli;
    type.reserve(4);
    type[0] = typ;
    type[1] = 'f';
    type[2] = 'f';
    type[3] = 'f';

}
/*
Space::Space(const Space &temp){
   
    row = temp.row;
    col = temp.col;
    type[0]=temp.type[0] ;
    type[1]=temp.type[1] ;
    type[2]= temp.type[2];
    type[3]=temp.type[3] ; 
}
*/
void Space::setRow(int r){
    row = r;
}
void Space::setCol(int c){
    col = c;
}
int Space::getRow(){
    return row;
}
int Space::getCol(){
    return col;
}
char Space::getType(){
    return type[0];
}
void Space::setType(char typ){
    type[0] = typ;
}
char Space::getExit(){
    return type[3];
}
void Space::setExit(char typ){
    type[3] = typ;
}
void Space::setVis(char typ){
    type[2] = typ;
}

char Space::getVis(){
    return type[2];
}
void Space::setP(char p){
    type[1] = p;
}

#endif

