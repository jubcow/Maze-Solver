#include <fstream>
#include <iostream>
#include <string>
#include "Maze.h"
#include "Space.h"

using namespace std;

int main(int argc, char *argv[]){

        if(argc != 2)
                cout << "usage: " << argv[0] << " <filename>\n";
        else{
                Maze maz(argv[1],1,0); //create the maze
                //cout << "File: " << argv[1] << endl;
                
                ifstream file(argv[1]);
                
                if(!file.is_open())
                    cout <<"where dat file at\n";
                    
                //system("clear");
                
                //cout << "Row and Col: " << maz.getSpace(2,2).getRow() << " " << maz.getSpace(2,2).getCol() << endl;
                //Space temp;
                //cout << "getType: " << temp.getType() << endl;     //CORE DUMP
                //temp =maz.getSpace(2,2);
                //cout << "getType: " << temp.getType() << endl;     //CORE DUMP CAUSED BY THIS <----------------
                //cout << "STACK\n";
                maz.findExitStack(maz.getSpace(1,0));
                
                //cout << "QUEUE\n";
                Maze maz2(argv[1],1,0);
                maz2.findExitQueue(maz2.getSpace(1,0)); 
                
        }
    return 0;
}

