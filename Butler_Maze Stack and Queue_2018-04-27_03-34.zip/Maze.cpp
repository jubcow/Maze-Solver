#ifndef MAZECPP
#define MAZECPP
#include <string>
#include <array>
#include <stack>
#include <queue>
#include <fstream>
#include <iostream>
#include <vector>
#include "Maze.h"
using namespace std;

Maze::Maze(){}

int sizex;
int sizey; //was inside constructor before
Maze::Maze(string maze, int initialR, int initialC){ //set an exit!!

        initialR=1;
        initialC=0;
        ifstream file(maze); //create a filestream

        int row;
        int col;
        
        file>>sizex>>sizey;
        
        //cout << "SizeX = " << sizex << "    and SizeY = " << sizey << endl;

        for(int i = 0; i < sizex; i++){ 
            for(int j = 0; j < sizey; j++){
                grid[i][j].setRow(i);
                grid[i][j].setCol(j);
                grid[i][j].setVis('f');
                grid[i][j].setExit('f');
                grid[i][j].setP('f');
                //cout << "Row: " << i << " Col: " << j << "   grid[i][j].getRow(): " << grid[i][j].getRow() << "   grid[i][j].getCol(): " << grid[i][j].getCol() << endl;
                grid[i][j].setType(' ');//all spaces should be blank now
            }
        }
        
        while(file>>row>>col){ //happens for every line after the first
            grid[row][col].setType('*');//setting walls
            //cout << row << " " << col << endl;
        }
        
        for(int i = 0; i < sizey; i++){ //SETTING EXIT
            if((grid[i][sizey-1]).getType() == ' '){
                grid[i][sizey-1].setExit('E');
            }
        }
        
        //grid[initialR][initialC].setType('P');  //TESTING grid REMOVE THIS FOR MIMIR TESTS <-----------------------------------------------------
}

void Maze::printMaze(){
    
    for(int i = 0; i < sizex; i++){
        for(int j = 0; j < sizey; j++){
            cout<< (grid[i][j]).getType(); //was <, but would cause core dumps in some mazes
        }
        cout << endl;
    }
    cout << endl;
}

bool Maze::setInitial(int r, int c){//only checks if input row/col is not a wall
    if(grid[r][c].getType() != '*'){
        currentR = r;
        currentC = c;
    
        return true;
    }
    else
        return false;
}

Space Maze::getSpace(int r, int c){
    //cout << "grid[r][c].getType(): '" << grid[r][c].getType() << "'" << endl;
    return grid[r][c];
}

/*make a random choice from the reachable neighbors like so:

int r = rand() %4;

Where l is the list of reachable neighbors, rnd is a Random object, and r is the index of the randomly selected neighbor.
*/ //could just use a random number and use that to select if statement ordervvv

stack<Space> Maze::getFreeNeighborsStack(Space currentSpace){ //checks up,down,left,right         WILL WANT TO ADD ANDS FOR VISITED       changing these to else ifs will allow for P's to be drawn, going down until wall is hit.
    int col=currentSpace.getCol();
    int row=currentSpace.getRow();
    
    if(row<sizey && grid[currentSpace.getRow()+1][currentSpace.getCol()].getType()!= '*' && grid[currentSpace.getRow()+1][currentSpace.getCol()].getType()==' '){
        
            freeNeighborsStack.push(grid[currentSpace.getRow()+1][currentSpace.getCol()]);
            //cout << "UP ADDED\n";
            solutionStack.push(grid[currentSpace.getRow()+1][currentSpace.getCol()]);
    }
    else if(col > 0 && (grid[currentSpace.getRow()][currentSpace.getCol()-1].getType()!= '*') && (grid[currentSpace.getRow()][currentSpace.getCol()-1].getType()==' ')){ 
        
            freeNeighborsStack.push(grid[currentSpace.getRow()][currentSpace.getCol()-1]);
            //cout << "LEFT ADDED\n";
            solutionStack.push(grid[currentSpace.getRow()][currentSpace.getCol()-1]);
            
    }
    else if(row > 0 && grid[currentSpace.getRow()-1][currentSpace.getCol()].getType()!= '*' && grid[currentSpace.getRow()-1][currentSpace.getCol()].getType()==' '){ 
            freeNeighborsStack.push(grid[currentSpace.getRow()-1][currentSpace.getCol()]);
            //cout << "DOWN ADDED\n";
            solutionStack.push(grid[currentSpace.getRow()-1][currentSpace.getCol()]);
    }
    else if(col < sizex && grid[currentSpace.getRow()][currentSpace.getCol()+1].getType()!= '*' && grid[currentSpace.getRow()][currentSpace.getCol()+1].getType()==' '){ 
            freeNeighborsStack.push(grid[currentSpace.getRow()][currentSpace.getCol()+1]);
            //cout << "RIGHT ADDED\n";
            solutionStack.push(grid[currentSpace.getRow()][currentSpace.getCol()+1]);
    }
    else{ //if no neighbors are ' '
        if(grid[currentSpace.getRow()][currentSpace.getCol()].getType() == 'P'){
            
            if((grid[currentSpace.getRow()+1][currentSpace.getCol()].getType()== 'P')){
                currentSpace = grid[currentSpace.getRow()+1][currentSpace.getCol()];
                freeNeighborsStack.pop();
                solutionStack.pop();
            }
            else if(grid[currentSpace.getRow()][currentSpace.getCol()-1].getType()== 'P'){
                currentSpace = grid[currentSpace.getRow()][currentSpace.getCol()-1];
                freeNeighborsStack.pop();
                solutionStack.pop();
            }
            else if(grid[currentSpace.getRow()-1][currentSpace.getCol()].getType()== 'P'){
                currentSpace = grid[currentSpace.getRow()-1][currentSpace.getCol()];
                freeNeighborsStack.pop();
                solutionStack.pop();
            }
            else if(grid[currentSpace.getRow()][currentSpace.getCol()+1].getType()== 'P'){
                currentSpace = grid[currentSpace.getRow()][currentSpace.getCol()+1];
                freeNeighborsStack.pop();
                solutionStack.pop();
            }
        }
    }
    return freeNeighborsStack;
}

bool Maze::findExitStack(Space currentSpace){ 

    bool found = false;
    freeNeighborsStack.push(currentSpace);
    solutionStack.push(currentSpace);
    printMaze();
    
    while(!freeNeighborsStack.empty() && found == false){
        //cout << "Top in freeneighborsStack at current is: " << ((getFreeNeighborsStack(currentSpace)).top()).getRow() << " " << ((getFreeNeighborsStack(currentSpace)).top()).getCol() << endl; //  FOR TROUBLESHOOTING
            
            (grid[currentSpace.getRow()][currentSpace.getCol()]).setType('P');
            currentSpace = getFreeNeighborsStack(currentSpace).top();
            
            //cin.ignore();
            printMaze();
            
            if((grid[currentSpace.getRow()][currentSpace.getCol()]).getExit()=='E'){ 
                grid[currentSpace.getRow()][currentSpace.getCol()].setType('P');
                found = true;
                //cin.ignore();
                printMaze();
            }
    }
    
    for(int i = 0; i < sizex; i++){ //resetting spaces 
            for(int j = 0; j < sizey; j++){
                if((grid[i][j]).getType() == 'P'){
                    grid[i][j].setType(' ');
                }
            }
        }
        
    while(!solutionStack.empty()){ //reset types and run through solution stack?
        //cout << "SOLUTION STACK:\n" << solutionStack.top().getRow() << " " << solutionStack.top().getCol() << endl; //CORRECT
        grid[solutionStack.top().getRow()][solutionStack.top().getCol()].setType('P');
        solutionStack.pop();
    }
    //cout << "Solution Stack\n";
    printMaze();
    
/*
Loop Until: stack is empty
    pop current index off the stack and mark it as visited
    If current index has any unvisited neighbors
        Choose a random unvisited neighbor index
        Remove the wall between the chosen neighbor index and the current index
        push the current index on the stack
        push the randomly choose neighbor index on the stack
    Continue the loop.
*/
    return true; //was commented out and worked
}

stack<Space> Maze::getSolutionStack(){
    return solutionStack;
    
}

queue<Space> Maze::getFreeNeighborsQueue(Space currentSpace){
    int col=currentSpace.getCol();
    int row=currentSpace.getRow();
    //cout<<"Get Free Neighbors Current Row and Col"<<row<<" "<<col<<endl;
    if(row<sizey && grid[currentSpace.getRow()+1][currentSpace.getCol()].getType()==' ' ){
    
            freeNeighborsQueue.push(grid[currentSpace.getRow()+1][currentSpace.getCol()]);
            //cout << "UP ADDED\n";
            solutionQueue.push(grid[currentSpace.getRow()+1][currentSpace.getCol()]);
            printMaze();
    }
    else if(col>0 &&(grid[currentSpace.getRow()][currentSpace.getCol()-1].getType()==' ')){ 
        
            freeNeighborsQueue.push(grid[currentSpace.getRow()][currentSpace.getCol()-1]);
            //cout << "LEFT ADDED\n";
            solutionQueue.push(grid[currentSpace.getRow()][currentSpace.getCol()-1]);
            printMaze();
    }
    else if(row>0 && grid[currentSpace.getRow()-1][currentSpace.getCol()].getType()==' '){ 
            freeNeighborsQueue.push(grid[currentSpace.getRow()-1][currentSpace.getCol()]);
            //cout << "DOWN ADDED\n";
            solutionQueue.push(grid[currentSpace.getRow()-1][currentSpace.getCol()]);
            printMaze();
    }
    else if(col<sizex && grid[currentSpace.getRow()][currentSpace.getCol()+1].getType()==' '){ 
            freeNeighborsQueue.push(grid[currentSpace.getRow()][currentSpace.getCol()+1]);
            //cout << "RIGHT ADDED\n";
            solutionQueue.push(grid[currentSpace.getRow()][currentSpace.getCol()+1]);
            Space temp= solutionQueue.front();
            printMaze();
            //cout<<"Added Row and Col: "<<temp.getRow()<<" "<<temp.getCol()<<endl;
    }
    else{ //if no neighbors are ' '
        //copy queue into vector and search for last interrsection space
        //but only u to last copied
        if(grid[currentSpace.getRow()][currentSpace.getCol()].getType() == 'P'){
            
            if((grid[currentSpace.getRow()+1][currentSpace.getCol()].getType()== 'P' && grid[currentSpace.getRow()+1][currentSpace.getCol()].getVis() != 't')){
                
                currentSpace=grid[currentSpace.getRow()+1][currentSpace.getCol()];
                //freeNeighborsQueue.pop();
                freeNeighborsQueue.push(currentSpace);
                //grid[currentSpace.getRow()+1][currentSpace.getCol()].setVis('t'); //setting to visited
                solutionQueue.pop();
            }
            else if(grid[currentSpace.getRow()][currentSpace.getCol()-1].getType()== 'P' && grid[currentSpace.getRow()][currentSpace.getCol()-1].getVis() != 't'){
                
                currentSpace=grid[currentSpace.getRow()][currentSpace.getCol()-1];
                
                freeNeighborsQueue.push(currentSpace);
                //grid[currentSpace.getRow()][currentSpace.getCol()-1].setVis('t'); //setting to visited
                solutionQueue.pop();
            }
            else if(grid[currentSpace.getRow()-1][currentSpace.getCol()].getType()== 'P' && grid[currentSpace.getRow()-1][currentSpace.getCol()].getVis() != 't'){
                
                currentSpace=grid[currentSpace.getRow()-1][currentSpace.getCol()];
                
                //freeNeighborsQueue.pop();
                freeNeighborsQueue.push(currentSpace);
                //grid[currentSpace.getRow()-1][currentSpace.getCol()].setVis('t'); //setting to visited
                solutionQueue.pop();
            }
            else if(grid[currentSpace.getRow()][currentSpace.getCol()+1].getType()== 'P' && grid[currentSpace.getRow()][currentSpace.getCol()+1].getVis() != 't'){
                
                currentSpace=grid[currentSpace.getRow()][currentSpace.getCol()+1];
                
                //freeNeighborsQueue.pop();
                freeNeighborsQueue.push(currentSpace);
                //grid[currentSpace.getRow()][currentSpace.getCol()+1].setVis('t'); //setting to visited
                solutionQueue.pop();
            }
        }
    }
    freeNeighborsQueue.pop();
    return freeNeighborsQueue; //yeet
}

bool Maze::findExitQueue(Space currentSpace){
    bool found = false;
    freeNeighborsQueue.push(currentSpace);
    
    printMaze();
    
    while(!freeNeighborsQueue.empty() && found == false){
        //cout << "front in freeNeighborsQueue at current: " << ((getFreeNeighborsQueue(currentSpace)).front()).getRow() << " " << ((getFreeNeighborsQueue(currentSpace)).front()).getCol() << endl; //  FOR TROUBLESHOOTING 
            //cout<<"Before Call to Get Neighbor= "<<currentSpace.getRow()<<" "<<currentSpace.getCol()<<endl;
             
            (grid[currentSpace. getRow()][currentSpace.getCol()]).setType('P');
            freeNeighborsQueue = getFreeNeighborsQueue(currentSpace);
            currentSpace = freeNeighborsQueue.front();
            
            //cout<<"Next Space After call= "<<currentSpace.getRow()<<" "<<currentSpace.getCol()<<endl;
            
            //cin.ignore();
            
            if((grid[currentSpace.getRow()][currentSpace.getCol()]).getExit()=='E'){ 
                grid[currentSpace.getRow()][currentSpace.getCol()].setType('P');
                found = true;
                //cin.ignore();
                printMaze();
                
            }
    }
    
    /*
    for(int i = 0; i < sizex; i++){ //resetting spaces 
            for(int j = 0; j < sizey; j++){
                if((grid[i][j]).getType() == 'P'){
                    grid[i][j].setType(' ');
                }
            }
        }
        
    while(!solutionQueue.empty()){ //reset types and run through solution stack?
        //cout << "SOLUTION STACK:\n" << solutionStack.top().getRow() << " " << solutionStack.top().getCol() << endl; //CORRECT
        grid[solutionQueue.front().getRow()][solutionQueue.front().getCol()].setType('P');
        solutionQueue.pop();
    }
    */
    //cout << "Solution Queue\n";
    printMaze();
    printMaze();

}
#endif
