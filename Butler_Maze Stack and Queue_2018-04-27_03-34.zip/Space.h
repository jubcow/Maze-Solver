#ifndef SPACEH
#define SPACEH
#include <vector>
#include <string>

class Space{
        public:
                Space();
                Space(char type, int rowi, int coli);
                //Space(const Space &temp);
                int getRow();
                int getCol();
                char getType();
                void setRow(int r);
                void setCol(int c);
                void setType(char typ);
                char getExit();
                void setExit(char typ);
                void setVis(char typ);
                char getVis();
                void setP(char p);
        private:
                std::vector<char> type; //do i need to declare chars for getExit?
                int row;
                int col;
};
#endif

